"use client";

import React, { useState, useEffect, useRef } from "react";
import $ from "jquery";
import "select2";
import "select2/dist/css/select2.min.css";

const ProductVariationTab = ({
  data = {},
  sizes = [],
  colors = [],
  updateData,
  default_size = null,
  default_color = null,
}) => {
  console.log("eiagysufd", sizes, colors);
  const [formData, setFormData] = useState({
    size_ids: [],
    color_ids: [],
    default_size: default_size || "",
    default_color: default_color || "",
  });

  const [tableData, setTableData] = useState({});
  const inputRefs = useRef({});

  // 🆕 Dynamic color code support
  const sampleSizes = Array.isArray(sizes)
    ? sizes
    : Object.entries(sizes).map(([id, label]) => ({
        id: Number(id),
        label,
        name: label,
      }));

  const sampleColors = Array.isArray(colors)
    ? colors.map((c) => ({
        id: c.id,
        name: c.name,
        hexa_code: c.hexa_code,
        hexa_code_2: c.hexa_code_2,
      }))
    : Object.entries(colors).map(([id, c]) => ({
        id: Number(id),
        name: c.name,
        hexa_code: c.hexa_code || "#ccc",
        hexa_code_2: c.hexa_code_2 || "#ccc",
      }));

  const getColorById = (id) =>
    sampleColors.find((c) => String(c.id) === String(id));

  useEffect(() => {
    const ids = ["#size_ids", "#color_ids"];
    ids.forEach((id) => {
      $(id)
        .select2({
          placeholder: "Select options",
          allowClear: true,
          width: "100%",
          theme: "default",
        })
        .on("change", function () {
          const field = $(this).attr("id");
          const selectedValues = $(this).val();
          handleSelectChange(field, selectedValues || []);
        });
    });

    return () => {
      ids.forEach((id) => {
        const $el = $(id);
        if ($el.data("select2")) {
          $el.select2("destroy");
        }
      });
    };
  }, []);

  const buildStructuredData = () => {
    let result = [];

    formData.color_ids.forEach((color_id) => {
      formData.size_ids.forEach((size_id) => {
        const stock = tableData[`${color_id}_${size_id}_qty`] || 0;
        const images = tableData[`${color_id}_image_files`] || [];

        result.push({
          color_id: Number(color_id),
          size_id: Number(size_id),
          stock: Number(stock),
          images,
          status:
            Number(color_id) === Number(formData.default_color) &&
            Number(size_id) === Number(formData.default_size)
              ? 1
              : 0,
        });
      });
    });

    return result;
  };

  useEffect(() => {
    if (updateData) {
      const structuredData = buildStructuredData();
      updateData(structuredData, formData.default_size, formData.default_color);
    }
  }, [formData, tableData]);

  const handleSelectChange = (field, selectedValues) => {
    setFormData((prev) => ({
      ...prev,
      [field]: selectedValues,
      ...(field === "size_ids" &&
      !selectedValues.includes(String(prev.default_size))
        ? { default_size: "" }
        : {}),
      ...(field === "color_ids" &&
      !selectedValues.includes(String(prev.default_color))
        ? { default_color: "" }
        : {}),
    }));
  };

  const setDefault = (field, value) => {
    if (field === "size") {
      setFormData((prev) => ({ ...prev, default_size: value }));
    } else if (field === "color") {
      setFormData((prev) => ({ ...prev, default_color: value }));
    }
  };

  const handleInputChange = (color_id, size_id, stock) => {
    setTableData((prev) => ({
      ...prev,
      [`${color_id}_${size_id}_qty`]: stock,
    }));
  };

  const handleImageChange = (color_id, files) => {
    const newFiles = Array.from(files);
    const previewUrls = newFiles.map((file) => URL.createObjectURL(file));

    setTableData((prev) => ({
      ...prev,
      [`${color_id}_image_files`]: newFiles,
      [`${color_id}_image_previews`]: [
        ...(prev[`${color_id}_image_previews`] || []),
        ...previewUrls,
      ],
    }));
  };

  const handleKeyDown = (e, color_id, size_id) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const colorIndex = formData.color_ids.indexOf(String(color_id));
      const sizeIndex = formData.size_ids.indexOf(String(size_id));
      let nextColorIndex = colorIndex;
      let nextSizeIndex = sizeIndex + 1;
      if (nextSizeIndex >= formData.size_ids.length) {
        nextSizeIndex = 0;
        nextColorIndex++;
      }
      if (nextColorIndex < formData.color_ids.length) {
        const nextColor = formData.color_ids[nextColorIndex];
        const nextSize = formData.size_ids[nextSizeIndex];
        const nextRef = inputRefs.current?.[nextColor]?.[nextSize];
        if (nextRef) nextRef.focus();
      }
    }
  };

  return (
    <div className="max-w-full p-6 dark:bg-transparent text-gray-900 dark:text-white">
      {/* Size Selector */}
      <div className="mb-6">
        <label htmlFor="size_ids" className="block text-sm font-medium mb-2">
          Size
        </label>
        <select
          id="size_ids"
          multiple
          className="w-full"
          defaultValue={formData.size_ids}
        >
          {sampleSizes.map((size) => (
            <option key={size.id} value={size.id}>
              {size.name}
            </option>
          ))}
        </select>
        <div className="flex flex-wrap gap-2 mt-2">
          {formData.size_ids.map((size_id) => {
            const sizeObj = sampleSizes.find((s) => s.id === Number(size_id));
            if (!sizeObj) return null;
            return (
              <div
                key={size_id}
                className="flex gap-2 items-center bg-gray-100 dark:bg-gray-800 p-2 rounded"
              >
                <span>{sizeObj.label || sizeObj.name}</span>
                <button
                  onClick={() => setDefault("size", sizeObj.id)}
                  className={`text-xs px-2 py-0.5 rounded ${
                    formData.default_size === sizeObj.id
                      ? "bg-red-600 text-white"
                      : "bg-gray-300 dark:bg-gray-700"
                  }`}
                >
                  {formData.default_size === sizeObj.id
                    ? "Default"
                    : "Make Default"}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Color Selector */}
      <div className="mb-6">
        <label htmlFor="color_ids" className="block text-sm font-medium mb-2">
          Color
        </label>
        <select
          id="color_ids"
          multiple
          className="w-full"
          defaultValue={formData.color_ids}
        >
          {sampleColors.map((color) => (
            <option key={color.id} value={color.id}>
              {color.name}
            </option>
          ))}
        </select>
        <div className="flex flex-wrap gap-2 mt-2">
          {formData.color_ids.map((color_id) => {
            const color = getColorById(color_id);
            return (
              <div
                key={color_id}
                className="flex gap-2 items-center bg-gray-100 dark:bg-gray-800 p-2 rounded"
              >
                <span
                  className="inline-block w-4 h-4 rounded-full border"
                  style={{
                    background: color.hexa_code_2
                      ? `linear-gradient(135deg, ${color.hexa_code} 50%, ${color.hexa_code_2} 50%)`
                      : color.hexa_code,
                  }}
                ></span>

                <span>{color.name}</span>
                <button
                  onClick={() => setDefault("color", color.id)}
                  className={`text-xs px-2 py-0.5 rounded ${
                    formData.default_color === color.id
                      ? "bg-red-600 text-white"
                      : "bg-gray-300 dark:bg-gray-700"
                  }`}
                >
                  {formData.default_color === color.id
                    ? "Default"
                    : "Make Default"}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Matrix Table */}
      {formData.size_ids.length > 0 && formData.color_ids.length > 0 && (
        <div className="overflow-x-auto border rounded shadow-sm">
          <table className="min-w-full table-fixed">
            <thead>
              <tr>
                <th className="px-3 py-2 text-left">Color / Size</th>
                {formData.size_ids.map((size_id) => {
                  const sizeObj = sampleSizes.find(
                    (s) => s.id === Number(size_id)
                  );
                  return (
                    <th key={size_id} className="px-3 py-2 text-center">
                      {sizeObj?.name}
                    </th>
                  );
                })}
                <th className="px-3 py-2 text-center">Images</th>
              </tr>
            </thead>
            <tbody>
              {formData.color_ids.map((color_id) => {
                const color = getColorById(color_id);
                return (
                  <tr key={color_id}>
                    <td className="px-3 py-2 font-medium flex items-center gap-2">
                      <span
                        className="inline-block w-4 h-4 rounded-full border"
                        style={{
                          background: color.hexa_code_2
                            ? `linear-gradient(135deg, ${color.hexa_code} 50%, ${color.hexa_code_2} 50%)`
                            : color.hexa_code,
                        }}
                      ></span>

                      {color.name}
                    </td>

                    {formData.size_ids.map((size_id) => {
                      if (!inputRefs.current[color_id])
                        inputRefs.current[color_id] = {};
                      return (
                        <td
                          key={`${color_id}_${size_id}`}
                          className="px-2 py-1"
                        >
                          <input
                            type="number"
                            min={0}
                            className="w-full text-center border rounded"
                            value={
                              tableData[`${color_id}_${size_id}_qty`] || ""
                            }
                            onChange={(e) =>
                              handleInputChange(
                                color_id,
                                size_id,
                                e.target.value
                              )
                            }
                            onKeyDown={(e) =>
                              handleKeyDown(e, color_id, size_id)
                            }
                            ref={(el) =>
                              (inputRefs.current[color_id][size_id] = el)
                            }
                          />
                        </td>
                      );
                    })}

                    <td className="px-2 py-1 min-w-[250px]">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={(e) =>
                          handleImageChange(color_id, e.target.files)
                        }
                        className="block w-full text-sm"
                      />
                      <div className="flex gap-1 mt-1 flex-wrap">
                        {(tableData[`${color_id}_image_previews`] || []).map(
                          (img, i) => (
                            <img
                              key={i}
                              src={img}
                              alt="preview"
                              className="w-12 h-12 object-cover rounded"
                            />
                          )
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ProductVariationTab;
