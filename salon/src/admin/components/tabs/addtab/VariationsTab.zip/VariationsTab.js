"use client";

import React, { useState, useEffect, useRef } from "react";
import $ from "jquery";
import "select2";
import "select2/dist/css/select2.min.css";

const ProductVariationTab = () => {
  const [formData, setFormData] = useState({
    sizes: [],
    colors: [],
    defaultSize: "",
    defaultColor: "",
  });
  const [tableData, setTableData] = useState({});
  const inputRefs = useRef({});

  const sampleSizes = [
    "XS",
    "S",
    "M",
    "L",
    "XL",
    "XXL",
    "3XL",
    "4XL",
    "5XL",
    "6XL",
    "7XL",
    "8XL",
    "9XL",
    "10XL",
    "11XL",
    "12XL",
    "13XL",
    "14XL",
  ];
  const sampleColors = ["Red", "Blue", "Green", "Yellow", "Black"];

  useEffect(() => {
    const ids = ["#sizes", "#colors"];
    ids.forEach((id) => {
      $(id)
        .select2({
          placeholder: "Select options",
          allowClear: true,
          width: "100%",
          theme: "default",
        })
        .on("change", function () {
          const field = $(this).attr("id");
          const selectedValues = $(this).val();
          handleSelectChange(field, selectedValues || []);
        });
    });

    return () => {
      ids.forEach((id) => {
        const $el = $(id);
        if ($el.data("select2")) {
          $el.select2("destroy");
        }
      });
    };
  }, []);

  const handleSelectChange = (field, selectedValues) => {
    setFormData((prev) => ({
      ...prev,
      [field]: selectedValues,
      ...(field === "sizes" && !selectedValues.includes(prev.defaultSize)
        ? { defaultSize: "" }
        : {}),
      ...(field === "colors" && !selectedValues.includes(prev.defaultColor)
        ? { defaultColor: "" }
        : {}),
    }));
  };

  const setDefault = (field, value) => {
    if (field === "size") {
      setFormData((prev) => ({ ...prev, defaultSize: value }));
    } else if (field === "color") {
      setFormData((prev) => ({ ...prev, defaultColor: value }));
    }
  };

  const handleInputChange = (color, size, value) => {
    setTableData((prev) => ({
      ...prev,
      [`${color}_${size}_qty`]: value,
    }));
  };

  const handleImageChange = (color, files) => {
    const newFileUrls = Array.from(files).map((file) =>
      URL.createObjectURL(file)
    );

    setTableData((prev) => {
      const key = `${color}_images`;
      const existing = prev[key] || [];
      return {
        ...prev,
        [key]: [...existing, ...newFileUrls],
      };
    });
  };

  const handleKeyDown = (e, color, size) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const colorIndex = formData.colors.indexOf(color);
      const sizeIndex = formData.sizes.indexOf(size);
      let nextColorIndex = colorIndex;
      let nextSizeIndex = sizeIndex + 1;
      if (nextSizeIndex >= formData.sizes.length) {
        nextSizeIndex = 0;
        nextColorIndex++;
      }
      if (nextColorIndex < formData.colors.length) {
        const nextColor = formData.colors[nextColorIndex];
        const nextSize = formData.sizes[nextSizeIndex];
        const nextRef = inputRefs.current?.[nextColor]?.[nextSize];
        if (nextRef) nextRef.focus();
      }
    }
  };

  const colorPalette = {
    Red: "bg-red-500",
    Blue: "bg-blue-500",
    Green: "bg-green-500",
    Yellow: "bg-yellow-400",
    Black: "bg-gray-800",
  };

  return (
    <div className="max-w-full p-6  dark:bg-transparent text-gray-900 dark:text-white">
      <div className="space-y-6">
        {/* Size Selection */}
        <div>
          <label htmlFor="sizes" className="block text-sm font-medium mb-2">
            Size
          </label>
          <select
            id="sizes"
            multiple
            className="w-full"
            defaultValue={formData.sizes}
          >
            {sampleSizes.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>

          {formData.sizes.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.sizes.map((size) => (
                <div
                  key={size}
                  className="flex items-center gap-2 border px-2 py-1 rounded bg-gray-100 dark:bg-gray-800"
                >
                  <span>{size}</span>
                  <button
                    type="button"
                    onClick={() => setDefault("size", size)}
                    className={`text-xs px-2 py-0.5 rounded ${
                      formData.defaultSize === size
                        ? "bg-red-600 text-white"
                        : "bg-gray-300 dark:bg-gray-700"
                    }`}
                  >
                    {formData.defaultSize === size ? "Default" : "Make Default"}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Color Selection */}
        <div>
          <label htmlFor="colors" className="block text-sm font-medium mb-2">
            Color
          </label>
          <select
            id="colors"
            multiple
            className="w-full"
            defaultValue={formData.colors}
          >
            {sampleColors.map((color) => (
              <option key={color} value={color}>
                {color}
              </option>
            ))}
          </select>

          {formData.colors.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.colors.map((color) => (
                <div
                  key={color}
                  className="flex items-center gap-2 border px-2 py-1 rounded bg-gray-100 dark:bg-gray-800"
                >
                  <span
                    className={`inline-block w-4 h-4 rounded-full mr-1 ${colorPalette[color]}`}
                  ></span>
                  <span>{color}</span>
                  <button
                    type="button"
                    onClick={() => setDefault("color", color)}
                    className={`text-xs px-2 py-0.5 rounded ${
                      formData.defaultColor === color
                        ? "bg-red-600 text-white"
                        : "bg-gray-300 dark:bg-gray-700"
                    }`}
                  >
                    {formData.defaultColor === color
                      ? "Default"
                      : "Make Default"}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Matrix Table */}
        {formData.colors.length > 0 && formData.sizes.length > 0 && (
          <div className="overflow-x-auto mt-6 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
            <table className="min-w-full table-fixed divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-800">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider border-r dark:border-gray-700">
                    Color/Size
                  </th>
                  {formData.sizes.map((size) => (
                    <th
                      key={size}
                      className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider border-l dark:border-gray-700"
                    >
                      {size}
                    </th>
                  ))}
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider border-l dark:border-gray-700">
                    Images
                  </th>
                </tr>
              </thead>
              <tbody className=" dark:bg-transparent divide-y divide-gray-200 dark:divide-gray-700">
                {formData.colors.map((color) => (
                  <tr key={color}>
                    <td className="px-4 py-2 text-sm font-medium text-gray-900 dark:text-white border-r dark:border-gray-700 sticky left-0  dark:bg-transparent">
                      <div className="flex items-center">
                        <span
                          className={`inline-block w-4 h-4 rounded-full mr-2 ${colorPalette[color]}`}
                        ></span>
                        {color}
                      </div>
                    </td>

                    {formData.sizes.map((size) => {
                      if (!inputRefs.current[color]) {
                        inputRefs.current[color] = {};
                      }
                      return (
                        <td
                          key={`${color}-${size}-qty`}
                          className="px-2 py-1 border-l dark:border-gray-700"
                        >
                          <input
                            type="number"
                            min={0}
                            max={100000}
                            value={tableData[`${color}_${size}_qty`] || ""}
                            onChange={(e) =>
                              handleInputChange(color, size, e.target.value)
                            }
                            onKeyDown={(e) => handleKeyDown(e, color, size)}
                            ref={(el) => (inputRefs.current[color][size] = el)}
                            className="w-full p-1 text-center rounded-md border border-gray-300 dark:border-gray-600 bg-transparent focus:ring-red-500 focus:border-red-500 text-gray-900 dark:text-white"
                          />
                        </td>
                      );
                    })}

                    <td className="px-2 py-1 border-l dark:border-gray-700 min-w-[300px]">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={(e) =>
                          handleImageChange(color, e.target.files)
                        }
                        className="block w-full text-sm text-gray-500 file:mr-4 file:py-1 file:px-2 file:border-0 file:text-sm file:font-semibold file:bg-red-50 file:text-red-700 hover:file:bg-red-100"
                      />
                      <div className="overflow-x-auto mt-1">
                        <div className="flex gap-2 w-fit min-w-full">
                          {(tableData[`${color}_images`] || []).map(
                            (img, i) => (
                              <img
                                key={i}
                                src={img}
                                alt={`Preview ${i}`}
                                className="w-12 h-12 object-cover rounded"
                              />
                            )
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductVariationTab;
