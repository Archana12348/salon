"use client";

import React, { useState, useEffect, useRef } from "react";
import $ from "jquery";
import "select2";
import "select2/dist/css/select2.min.css";

const ProductLinksTab = ({
  categories = [],
  subcategories = [],
  childcategories = [],
  tags = [],
  products = [],
  formDatas,
}) => {
  const [formData, setFormData] = useState({
    mainCategory: [],
    subCategory: [],
    childCategory: [],
    tags: [],
    relatedProducts: [],
  });

  const [filteredSubcategories, setFilteredSubcategories] = useState([]);
  const [filteredChildcategories, setFilteredChildcategories] = useState([]);
  const select2Initialized = useRef(false);

  const handleSelectChange = (field, selectedValuesRaw) => {
    const selectedValues = selectedValuesRaw || [];

    setFormData((prev) => ({
      ...prev,
      [field]: selectedValues,
    }));

    if (field === "mainCategory") {
      const filtered = subcategories.filter((sub) =>
        selectedValues.includes(String(sub.product_category_id))
      );
      setFilteredSubcategories(filtered);
      setFilteredChildcategories([]);

      // Reset dependent fields
      setFormData((prev) => ({
        ...prev,
        subCategory: [],
        childCategory: [],
      }));

      // Reinitialize Select2 for dependent fields
      setTimeout(() => {
        $("#subCategory").val(null).trigger("change");
        $("#childCategory").val(null).trigger("change");
      }, 100);
    }

    if (field === "subCategory") {
      const filtered = childcategories.filter((child) =>
        selectedValues.includes(String(child.product_subcategory_id))
      );
      setFilteredChildcategories(filtered);

      // Reset child category
      setFormData((prev) => ({ ...prev, childCategory: [] }));

      // Reinitialize Select2 for child category
      setTimeout(() => {
        $("#childCategory").val(null).trigger("change");
      }, 100);
    }
  };

  const initializeSelect2 = () => {
    const ids = [
      "#mainCategory",
      "#subCategory",
      "#childCategory",
      "#relatedProducts",
      "#tags",
    ];

    ids.forEach((id) => {
      $(id)
        .select2({
          placeholder: "Select options",
          allowClear: true,
          width: "100%",
          theme: "default",
        })
        .on("change", function () {
          const field = $(this).attr("id");
          const selectedValues = $(this).val() || [];
          handleSelectChange(field, selectedValues);
        });
    });

    select2Initialized.current = true;
  };

  const destroySelect2 = () => {
    const ids = [
      "#mainCategory",
      "#subCategory",
      "#childCategory",
      "#relatedProducts",
      "#tags",
    ];

    ids.forEach((id) => {
      $(id).off("change").select2("destroy");
    });

    select2Initialized.current = false;
  };

  useEffect(() => {
    // Initialize Select2 only once
    if (!select2Initialized.current) {
      initializeSelect2();
    }

    // Set initial data if formDatas is provided
    if (formDatas) {
      const initialFormData = {
        mainCategory: formDatas.head_categories?.map((c) => String(c.id)) || [],
        subCategory:
          formDatas.parent_categories?.map((s) => String(s.id)) || [],
        childCategory:
          formDatas.child_categories?.map((c) => String(c.id)) || [],
        relatedProducts:
          formDatas.related_products?.map((p) => String(p.id)) || [],
        tags: formDatas.tags?.map((t) => String(t.id)) || [],
      };

      // Filter subcategories based on selected main categories
      const filteredSubs = subcategories.filter((sub) =>
        initialFormData.mainCategory.includes(String(sub.product_category_id))
      );
      setFilteredSubcategories(filteredSubs);

      // Filter childcategories based on selected sub categories
      const filteredChildren = childcategories.filter((child) =>
        initialFormData.subCategory.includes(
          String(child.product_subcategory_id)
        )
      );
      setFilteredChildcategories(filteredChildren);

      // Update state
      setFormData(initialFormData);

      // Set Select2 values after a small delay to ensure DOM is ready
      setTimeout(() => {
        Object.entries(initialFormData).forEach(([key, value]) => {
          $(`#${key}`).val(value).trigger("change");
        });
      }, 300);
    }

    console.log("filteredSubcategories", filteredSubcategories);
    console.log("filteredChildcategories", filteredChildcategories);
    debugger;
    return () => {
      destroySelect2();
    };
  }, [formDatas, subcategories, childcategories]);

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="dark:bg-transparent shadow-md rounded-lg overflow-hidden">
        <div className="md:p-8 p-4">
          <form>
            <div className="space-y-6">
              {/* Main Category */}
              <div>
                <label
                  htmlFor="mainCategory"
                  className="block text-sm font-medium mb-2 dark:text-white"
                >
                  Main Category
                </label>
                <select id="mainCategory" multiple className="w-full">
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Sub Category */}
              <div>
                <label
                  htmlFor="subCategory"
                  className="block text-sm font-medium mb-2 dark:text-white"
                >
                  Sub Category
                </label>
                <select id="subCategory" multiple className="w-full">
                  {filteredSubcategories.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
                {filteredSubcategories.length === 0 &&
                  formData.mainCategory.length > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      No subcategories found for the selected main categories
                    </p>
                  )}
              </div>

              {/* Child Category */}
              <div>
                <label
                  htmlFor="childCategory"
                  className="block text-sm font-medium mb-2 dark:text-white"
                >
                  Child Category
                </label>
                <select id="childCategory" multiple className="w-full">
                  {filteredChildcategories.map((child) => (
                    <option key={child.id} value={child.id}>
                      {child.name}
                    </option>
                  ))}
                </select>
                {filteredChildcategories.length === 0 &&
                  formData.subCategory.length > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      No child categories found for the selected subcategories
                    </p>
                  )}
              </div>

              {/* Related Products */}
              {/* <div>
                <label
                  htmlFor="relatedProducts"
                  className="block text-sm font-medium mb-2 dark:text-white"
                >
                  Related Products
                </label>
                <select id="relatedProducts" multiple className="w-full">
                  {products.map((product) => (
                    <option key={product.id} value={product.id}>
                      {product.name}
                    </option>
                  ))}
                </select>
              </div> */}

              {/* Tags */}
              <div>
                <label
                  htmlFor="tags"
                  className="block text-sm font-medium mb-2 dark:text-white"
                >
                  Tags
                </label>
                <select id="tags" multiple className="w-full">
                  {tags.map((tag) => (
                    <option key={tag.id} value={tag.id}>
                      {tag.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProductLinksTab;
