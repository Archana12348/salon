import React, { useState, useEffect } from "react";
import axios from "axios";
import { Edit, Trash2, Plus } from "lucide-react";
import Button from "../../../components/ui/Button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../../components/ui/Table";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import Input from "../../../components/ui/Input";
import {
  CardHeader,
  CardTitle,
  CardDescription,
} from "../../../components/ui/Card";
import PermissionGuard from "../../../components/auth/PermissionGuard";

const ChildCategoriesTable = () => {
  const [headCategories, setHeadCategories] = useState([]);
  const [parentCategories, setParentCategories] = useState([]);
  const [childCategories, setChildCategories] = useState([]);
  const [selectedChildren, setSelectedChildren] = useState([]);
  const [areAllOnPageSelected, setAreAllOnPageSelected] = useState(false);

  // ✅ Pagination & Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [lastPage, setLastPage] = useState(1);
  const [totalEntries, setTotalEntries] = useState(0);
  const [sortDir] = useState("desc"); // default

  const navigate = useNavigate();

  // ✅ Fetch data from backend with page, perPage, search
  const fetchData = async (page = 1, perPage = entriesPerPage, search = "") => {
    try {
      const [headRes, parentRes, childRes] = await Promise.all([
        axios.get(
          "https://tyka.premierhostings.com/backend/api/product-categories"
        ),
        axios.get(
          "https://tyka.premierhostings.com/backend/api/product-sub-categories"
        ),
        axios.get(
          `https://tyka.premierhostings.com/backend/api/product-child-categories?page=${page}&perPage=${perPage}&search=${search}&sortDir=${sortDir}`
        ),
      ]);

      setHeadCategories(headRes.data.data || []);
      setParentCategories(parentRes.data.data || []);
      setChildCategories(childRes.data.data || []);
      setCurrentPage(childRes.data.meta.current_page);
      setLastPage(childRes.data.meta.last_page);
      setTotalEntries(childRes.data.meta.total);
      setSelectedChildren([]);
      setAreAllOnPageSelected(false);
    } catch (error) {
      console.error("Error fetching categories:", error);
      toast.error("Failed to load categories from API.");
    }
  };

  useEffect(() => {
    fetchData(currentPage, entriesPerPage, searchTerm);
  }, [currentPage, entriesPerPage, searchTerm]);

  const handleSelectAllCategories = () => {
    if (areAllOnPageSelected) {
      setSelectedChildren([]);
    } else {
      setSelectedChildren(childCategories.map((c) => c.id));
    }
    setAreAllOnPageSelected(!areAllOnPageSelected);
  };

  const handleSelectCategory = (id) => {
    if (selectedChildren.includes(id)) {
      setSelectedChildren(selectedChildren.filter((cid) => cid !== id));
    } else {
      setSelectedChildren([...selectedChildren, id]);
    }
  };

  const deleteCategory = async (id) => {
    try {
      await axios.delete(
        `https://tyka.premierhostings.com/backend/api/product-child-categories/${id}`
      );
      fetchData(currentPage, entriesPerPage, searchTerm);
      toast.success("Child category deleted successfully!");
    } catch (error) {
      console.error("Delete error:", error);
      toast.error("Failed to delete child category.");
    }
  };

  const handleBulkDelete = async () => {
    try {
      await Promise.all(
        selectedChildren.map((id) =>
          axios.delete(
            `https://tyka.premierhostings.com/backend/api/product-child-categories/${id}`
          )
        )
      );
      fetchData(currentPage, entriesPerPage, searchTerm);
      setSelectedChildren([]);
      setAreAllOnPageSelected(false);
      toast.success("Selected child categories deleted successfully!");
    } catch (err) {
      toast.error("Bulk delete failed.");
      console.error(err);
    }
  };

  return (
    <div className="overflow-x-auto p-4">
      {/* Header */}
      <CardHeader className="space-y-4">
        <div className="flex flex-col space-y-2">
          <CardTitle className="text-lg sm:text-xl">Child Categories</CardTitle>
          <CardDescription className="text-sm">
            Manage your lowest-level product categories
          </CardDescription>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 w-full">
          {selectedChildren.length > 0 && (
            <PermissionGuard permission="bulk_delete_child_categories">
              <Button
                className="flex-shrink-0 w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white"
                onClick={handleBulkDelete}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Bulk Delete ({selectedChildren.length})
              </Button>
            </PermissionGuard>
          )}
          <PermissionGuard permission="create_child_categories">
            <Button
              className="flex-shrink-0 w-full sm:w-auto"
              onClick={() => navigate("/add-childcategory")}
            >
              <Plus className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Add Child Category</span>
              <span className="sm:hidden">Add</span>
            </Button>
          </PermissionGuard>
        </div>
      </CardHeader>

      {/* Show per page + Search */}
      <div className="flex flex-col sm:flex-row justify-between gap-3">
        <div className="flex items-center gap-2 ml-4">
          <label>Show</label>
          <select
            value={entriesPerPage}
            onChange={(e) => {
              setEntriesPerPage(Number(e.target.value));
              setCurrentPage(1); // reset page
            }}
            className="border rounded p-1 text-sm mb-1 dark:bg-slate-500"
          >
            {[10, 20, 50, 100].map((num) => (
              <option key={num} value={num}>
                {num}
              </option>
            ))}
          </select>
          <label>entries</label>
        </div>
        <div className="flex items-center px-3 py-2 w-full sm:w-64">
          <Input
            placeholder="Search by head, parent, child, slug..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1); // reset to first page
            }}
            className="border-none p-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 w-full"
          />
        </div>
      </div>

      {/* Table */}
      <Table className="min-w-[800px] w-full">
        <TableHeader>
          <TableRow className="border-b border-gray-200">
            <TableHead className="w-[50px]">
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-red-600 rounded border-gray-300 focus:ring-red-500"
                checked={
                  childCategories.length > 0 &&
                  selectedChildren.length === childCategories.length
                }
                onChange={handleSelectAllCategories}
              />
            </TableHead>
            <TableHead className="min-w-[150px]">Head Category</TableHead>
            <TableHead className="min-w-[150px]">Parent Category</TableHead>
            <TableHead className="min-w-[150px]">Child Category Name</TableHead>
            <TableHead className="min-w-[150px]">Slug</TableHead>
            <TableHead className="min-w-[100px] text-center">Actions</TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          {childCategories.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-4 text-gray-500">
                No child categories found.
              </TableCell>
            </TableRow>
          ) : (
            childCategories.map((cat) => (
              <TableRow key={cat.id}>
                <TableCell>
                  <input
                    type="checkbox"
                    className="form-checkbox h-4 w-4 text-red-600 rounded border-gray-300 focus:ring-red-500"
                    checked={selectedChildren.includes(cat.id)}
                    onChange={() => handleSelectCategory(cat.id)}
                  />
                </TableCell>
                <TableCell className="font-medium">
                  {headCategories.find((h) => h.id === cat.product_category_id)
                    ?.name || "N/A"}
                </TableCell>
                <TableCell className="font-medium">
                  {parentCategories.find(
                    (p) => p.id === cat.product_subcategory_id
                  )?.name || "N/A"}
                </TableCell>
                <TableCell className="font-medium">{cat.name}</TableCell>
                <TableCell className="font-medium text-gray-500">
                  {cat.slug}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <PermissionGuard permission="edit_child_categories">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() =>
                          navigate(`/edit-childcategory/${cat.id}`)
                        }
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </PermissionGuard>
                    <PermissionGuard permission="delete_child_categories">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteCategory(cat.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </PermissionGuard>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {/* Bottom Controls */}

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mt-4 text-sm text-gray-600 gap-2">
        {/* Showing entries */}
        <div>
          Showing{" "}
          {(childCategories.length && (currentPage - 1) * entriesPerPage + 1) ||
            0}{" "}
          to {(currentPage - 1) * entriesPerPage + childCategories.length} of{" "}
          {totalEntries} entries
        </div>

        {/* Pagination */}
        <div className="flex items-center gap-1 flex-wrap">
          {/* Previous Button */}
          <button
            className="px-3 py-1 border rounded disabled:opacity-50"
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            Previous
          </button>

          {/* First Page */}
          <button
            className={`px-3 py-1 border rounded ${
              currentPage === 1
                ? "bg-red-500 text-white"
                : "bg-gray-200 text-gray-700"
            }`}
            onClick={() => setCurrentPage(1)}
          >
            1
          </button>

          {/* Left Dots */}
          {currentPage > 3 && <span className="px-2">...</span>}

          {/* Dynamic Middle Pages */}
          {Array.from({ length: 3 }, (_, i) => {
            const pageNumber = currentPage - 1 + i;
            if (pageNumber > 1 && pageNumber < lastPage) {
              return (
                <button
                  key={pageNumber}
                  onClick={() => setCurrentPage(pageNumber)}
                  className={`px-3 py-1 border rounded ${
                    currentPage === pageNumber
                      ? "bg-red-500 text-white"
                      : "bg-gray-200 text-gray-700"
                  }`}
                >
                  {pageNumber}
                </button>
              );
            }
            return null;
          })}

          {/* Right Dots */}
          {currentPage < lastPage - 2 && <span className="px-2">...</span>}

          {/* Last Page */}
          {lastPage > 1 && (
            <button
              className={`px-3 py-1 border rounded ${
                currentPage === lastPage
                  ? "bg-red-500 text-white"
                  : "bg-gray-200 text-gray-700"
              }`}
              onClick={() => setCurrentPage(lastPage)}
            >
              {lastPage}
            </button>
          )}

          {/* Next Button */}
          <button
            className="px-3 py-1 border rounded disabled:opacity-50"
            onClick={() =>
              setCurrentPage((prev) => Math.min(prev + 1, lastPage))
            }
            disabled={currentPage === lastPage}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChildCategoriesTable;
