"use client";

import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import GeneralTab from "../../../components/tabs/edittab/GeneralTab";
import DataTab from "../../../components/tabs/edittab/DataTab";
import LinksTab from "../../../components/tabs/edittab/ProductLinksTab";
import ImagesTab from "../../../components/tabs/edittab/ImagesTab";
import VariationsTab from "../../../components/tabs/edittab/ProductVariationTab";

const ProductManagementFormEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditMode = !!id;

  const [activeTab, setActiveTab] = useState("general");
  const [loading, setLoading] = useState(false);

  const [productData, setProductData] = useState({
    name: "",
    slug: "",
    short_description: "",
    description: "",
    video_url: "",
    meta_title: "",
    meta_description: "",
    meta_keyword: "",
    status: false,
    is_new: false,
    is_featured: false,
    is_top_selling: false,
    is_sale: false,
    is_special_offer: false,
    sku: "",
    hsn: "",
    cost_price: "",
    selling_price: "",
    discount: "",
    gst: "",

    // extra
    categories: [],
    sub_categories: [],
    child_categories: [],
    product_tags: [],
    product_new_tags: [],
    product_colors: [],
    product_sizes: [],
    seasons: [],
    fabric_types: [],
    discounts: [],
    brands: [],
    related_products: [],
    default_image: null,
    images: [],
    variants: [],
  });

  // ✅ parent updater
  const updateData = (field, value) => {
    console.log(field, value);

    setProductData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // ✅ Fetch Data
  useEffect(() => {
    if (isEditMode) {
      fetch(
        `https://tyka.premierwebtechservices.com/backend/api/products/${id}/edit`
      )
        .then((res) => res.json())
        .then((response) => {
          console.log("🛠 Edit Response:", response);

          if (response?.data) {
            setProductData((prev) => ({
              ...prev,
              ...response.data, // ✅ product details
              categories: response.categories || [],
              new_categories: response.new_categories || [],
              sub_categories: response.sub_categories || [],
              child_categories: response.child_categories || [],
              product_tags: response.product_tags || [],
              product_new_tags: response.product_new_tags || [],
              product_colors: response.product_colors || [],
              product_sizes: response.product_sizes || [],
              variants: response.variants || [],
              seasons: response.seasons || [],
              fabric_types: response.fabric_types || [],
              discounts: response.discounts || [],
              brands: response.brands || [],
              related_products: response.related_products || [],
            }));
          }
        })
        .catch((err) => console.error("❌ Edit Product Error:", err));
    } else {
      fetch(
        `https://tyka.premierwebtechservices.com/backend/api/products/create`
      )
        .then((res) => res.json())
        .then((response) => {
          console.log("🛠 Create Response:", response);
          setProductData((prev) => ({
            ...prev,
            ...response,
          }));
        })
        .catch((err) => console.error("❌ Create Product Error:", err));
    }
  }, [id, isEditMode]);

  const appendFormData = (formData, key, value) => {
    if (value === null || value === undefined) return;

    if (Array.isArray(value)) {
      value.forEach((item, idx) => {
        appendFormData(formData, `${key}[${idx}]`, item);
      });
    } else if (typeof value === "object" && !(value instanceof File)) {
      Object.keys(value).forEach((subKey) => {
        appendFormData(formData, `${key}[${subKey}]`, value[subKey]);
      });
    } else {
      formData.append(key, value);
    }
  };

  // ✅ Save handler
  const handleSave = async () => {
    setLoading(true);

    const formData = new FormData();

    for (const key in productData) {
      const value = productData[key];

      if (["status", "new", "featured", "top_selling", "sale"].includes(key)) {
        formData.append(key, value ? 1 : 0);
      } else if (key === "images" && Array.isArray(value)) {
        value.forEach((item) => {
          if (item instanceof File) {
            formData.append("images[]", item);
          }
        });
      } else if (key === "default_image") {
        if (value instanceof File) {
          formData.append("default_image", value);
        }
      } else {
        appendFormData(formData, key, value);
      }
    }
    console.log("hello", formData);
    debugger;

    // validation example
    if (!productData.name || productData.name.trim() === "") {
      toast.error("❌ Product name is required.");
      setLoading(false);
      return;
    }

    try {
      const url = `https://tyka.premierwebtechservices.com/backend/api/products/${id}`;

      const method = "PUT";
      console.log(productData, isEditMode);
      debugger;
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(productData),
      });

      const result = await response.json();
      console.log("✅ Save Result:", result);

      if (result?.success) {
        toast.success("✅ Product Update successfully!");
        navigate("/products");
      } else {
        toast.error("❌ Failed to Update product.");
      }
    } catch (error) {
      console.error("❌ Save Error:", error);
      toast.error("❌ Something went wrong!");
    }

    setLoading(false);
  };

  // ✅ Tabs config
  const tabs = [
    {
      id: "general",
      label: "General",
      content: <GeneralTab data={productData} updateData={updateData} />,
    },
    {
      id: "data",
      label: "Data",
      content: (
        <DataTab
          tags={productData.product_new_tags}
          seasons={productData.seasons}
          fabrics={productData.fabric_types}
          brands={productData.brands}
          discounts={productData.discounts}
          formData={productData}
          updateData={updateData}
        />
      ),
    },
    {
      id: "links",
      label: "Links",
      content: (
        <LinksTab
          categories={productData.new_categories}
          subcategories={productData.sub_categories}
          childcategories={productData.child_categories}
          products={productData.related_products}
          tags={productData.product_new_tags}
          formDatas={productData}
          updateData={updateData}
        />
      ),
    },
    {
      id: "images",
      label: "Images",
      content: <ImagesTab data={productData} updateData={updateData} />,
    },
    {
      id: "variations",
      label: "Variations",
      content: (
        <VariationsTab
          colors={productData.product_colors}
          sizes={productData.product_sizes}
          data={productData.variants}
          updateData={(variants, default_size, default_color) =>
            setProductData((prev) => ({
              ...prev,
              variants,
              default_size,
              default_color,
            }))
          }
        />
      ),
    },
  ];

  // helpers for navigation
  const getCurrentTabIndex = () => tabs.findIndex((t) => t.id === activeTab);
  const goToNextTab = () => {
    const idx = getCurrentTabIndex();
    if (idx < tabs.length - 1) setActiveTab(tabs[idx + 1].id);
  };
  const goToPreviousTab = () => {
    const idx = getCurrentTabIndex();
    if (idx > 0) setActiveTab(tabs[idx - 1].id);
  };

  const renderTabContent = () =>
    tabs.find((tab) => tab.id === activeTab)?.content;

  return (
    <div
      className="product-form-container dark:bg-gray-900 dark:text-white bg-transparent"
      style={{
        width: "100%",
        overflowY: "hidden",
        overflowX: "auto",
        WebkitOverflowScrolling: "touch",
      }}
    >
      <div style={{ minWidth: "768px", paddingBottom: "20px" }}>
        {/* Header */}
        <div
          className="dark:text-white"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "20px 10px",
          }}
        >
          <h2 style={{ margin: 0, fontSize: "20px", fontWeight: "600" }}>
            {isEditMode ? "Edit Product" : "Add Product"}
          </h2>
        </div>

        <hr className="border-gray-300 dark:border-gray-700 mt-0" />

        {/* Tabs */}
        <div
          className="dark:text-white"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "10px 10px 0",
          }}
        >
          <div style={{ display: "flex", gap: "10px" }}>
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  padding: "8px 16px",
                  border: "none",
                  borderBottom:
                    activeTab === tab.id
                      ? "3px solid #dc2626"
                      : "3px solid transparent",
                  backgroundColor:
                    activeTab === tab.id ? "#dc2626" : "transparent",
                  color: activeTab === tab.id ? "#fff" : "inherit",
                  fontWeight: activeTab === tab.id ? "bold" : "normal",
                  borderRadius: "5px 5px 0 0",
                  cursor: "pointer",
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <hr className="border-gray-300 dark:border-gray-700 mt-0" />

        {/* Tab Content */}
        <div
          className="tab-content dark:text-white"
          style={{ padding: "20px" }}
        >
          {renderTabContent()}
        </div>

        <hr className="border-gray-300 dark:border-gray-700 mt-0" />

        {/* Navigation */}
        <div
          className="form-navigation"
          style={{
            padding: "0 20px 20px",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <button
            onClick={goToPreviousTab}
            disabled={getCurrentTabIndex() === 0}
            className="px-3 py-1 text-sm bg-red-500 hover:bg-red-600 text-white disabled:bg-gray-300 disabled:text-gray-500"
            style={{
              padding: "8px 16px",
              border: "none",
              borderRadius: "4px",
              fontWeight: "bold",
              cursor: "pointer",
              marginTop: "14px",
            }}
          >
            ← Previous
          </button>

          {getCurrentTabIndex() === tabs.length - 1 && (
            <button
              onClick={handleSave}
              style={{
                padding: "8px 16px",
                backgroundColor: "#dc2626",
                color: "#fff",
                border: "none",
                borderRadius: "4px",
                fontWeight: "bold",
                cursor: "pointer",
                marginTop: "14px",
              }}
              disabled={loading}
            >
              {loading ? "Saving..." : "Save Product"}
            </button>
          )}

          <button
            onClick={goToNextTab}
            disabled={getCurrentTabIndex() === tabs.length - 1}
            className="px-3 py-1 text-sm bg-red-500 hover:bg-red-600 text-white disabled:bg-gray-300 disabled:text-gray-500"
            style={{
              padding: "8px 16px",
              border: "none",
              borderRadius: "4px",
              fontWeight: "bold",
              cursor: "pointer",
              marginTop: "14px",
            }}
          >
            Next →
          </button>
        </div>

        <hr className="border-gray-300 dark:border-gray-700 mt-0" />
      </div>

      {/* Toastify Container */}
      <ToastContainer />
    </div>
  );
};

export default ProductManagementFormEdit;
